# unity_2d_test

test project following https://noobtuts.com/unity/2d-pacman-game
